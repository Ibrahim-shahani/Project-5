# project-3-Road-accident-Data-Analysis
"Project 3: Excel-driven analysis of road accident data, revealing key trends and factors to inform safety measures and policy decisions."
